#ifndef CALCULATOR_CALCULATOR_H
#define CALCULATOR_CALCULATOR_H


class Calculator
{
public:
    Calculator();
};


#endif //CALCULATOR_CALCULATOR_H
