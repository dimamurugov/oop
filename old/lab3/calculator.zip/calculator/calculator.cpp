#include "calculator.h"

Calculator::Calculator() = default;